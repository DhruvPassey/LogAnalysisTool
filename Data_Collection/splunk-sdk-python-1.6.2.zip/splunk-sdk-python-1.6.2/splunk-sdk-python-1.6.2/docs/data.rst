splunklib.data
--------------

.. automodule:: splunklib.data

.. autofunction:: load

.. autofunction:: record

.. autoclass:: Record
    :members: 

